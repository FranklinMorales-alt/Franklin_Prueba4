peliculas = []

# =========================
# MENÚ
# =========================

def mostrar_menu():
    print("\n========== MENÚ PRINCIPAL ==========")
    print("1. Agregar película")
    print("2. Buscar película")
    print("3. Eliminar película")
    print("4. Actualizar disponibilidad")
    print("5. Mostrar películas")
    print("6. Salir")
    print("====================================")


def leer_opcion():
    while True:
        try:
            opcion = int(input("Ingrese opción: "))
            if 1 <= opcion <= 6:
                return opcion
            else:
                print("Debe ingresar un número entre 1 y 6.")
        except ValueError:
            print("Debe ingresar un número válido.")


# =========================
# VALIDACIONES
# =========================

def validar_titulo(titulo):
    return titulo.strip() != ""


def validar_duracion(duracion):
    return duracion > 0


def validar_calificacion(calificacion):
    return 0.0 <= calificacion <= 10.0


# =========================
# AGREGAR PELÍCULA
# =========================

def agregar_pelicula(lista):
    titulo = input("Ingrese título: ")

    if not validar_titulo(titulo):
        print("Error: título inválido.")
        return

    try:
        duracion = int(input("Ingrese duración en minutos: "))
    except ValueError:
        print("Error: duración inválida.")
        return

    if not validar_duracion(duracion):
        print("Error: la duración debe ser mayor a 0.")
        return

    try:
        calificacion = float(input("Ingrese calificación (0.0 - 10.0): "))
    except ValueError:
        print("Error: calificación inválida.")
        return

    if not validar_calificacion(calificacion):
        print("Error: calificación fuera de rango.")
        return

    pelicula = {
        "titulo": titulo.strip(),
        "duracion": duracion,
        "calificacion": calificacion,
        "disponible": False
    }

    lista.append(pelicula)
    print("Película agregada correctamente.")


# =========================
# BUSCAR PELÍCULA
# =========================

def buscar_pelicula(lista, titulo):
    for i in range(len(lista)):
        if lista[i]["titulo"] == titulo:
            return i
    return -1


# =========================
# ELIMINAR PELÍCULA
# =========================

def eliminar_pelicula(lista, titulo):
    pos = buscar_pelicula(lista, titulo)

    if pos == -1:
        print(f"La película '{titulo}' no se encuentra registrada.")
    else:
        lista.pop(pos)
        print("Película eliminada correctamente.")


# =========================
# ACTUALIZAR DISPONIBILIDAD
# =========================

def actualizar_disponibilidad(lista):
    for pelicula in lista:
        if pelicula["calificacion"] >= 7.0:
            pelicula["disponible"] = True
        else:
            pelicula["disponible"] = False


# =========================
# MOSTRAR PELÍCULAS
# =========================

def mostrar_peliculas(lista):
    actualizar_disponibilidad(lista)

    print("\n=== LISTA DE PELICULAS ===\n")

    for pelicula in lista:
        print(f"Título: {pelicula['titulo']}")
        print(f"Duración: {pelicula['duracion']}")
        print(f"Calificación: {pelicula['calificacion']}")

        if pelicula["disponible"]:
            print("Estado: DISPONIBLE")
        else:
            print("Estado: NO RECOMENDADA")

        print("********************************************")


# =========================
# PROGRAMA PRINCIPAL
# =========================

while True:
    mostrar_menu()
    opcion = leer_opcion()

    if opcion == 1:
        agregar_pelicula(peliculas)

    elif opcion == 2:
        titulo = input("Ingrese título a buscar: ")
        pos = buscar_pelicula(peliculas, titulo)

        if pos == -1:
            print("No existe ningún registro con ese título.")
        else:
            print(f"Posición: {pos}")
            print(f"Título: {peliculas[pos]['titulo']}")
            print(f"Duración: {peliculas[pos]['duracion']}")
            print(f"Calificación: {peliculas[pos]['calificacion']}")
            print("Estado:", "DISPONIBLE" if peliculas[pos]["disponible"] else "NO RECOMENDADA")

    elif opcion == 3:
        titulo = input("Ingrese título a eliminar: ")
        eliminar_pelicula(peliculas, titulo)

    elif opcion == 4:
        actualizar_disponibilidad(peliculas)

    elif opcion == 5:
        mostrar_peliculas(peliculas)

    elif opcion == 6:
        print("Gracias por usar el sistema. Vuelva Pronto")
        break